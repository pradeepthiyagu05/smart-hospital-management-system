<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - HMS</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        .navbar {
            background: #2196F3;
            padding: 1rem;
            color: white;
            display: flex;
            justify-content: space-between;
        }
        .menu {
            display: flex;
            gap: 2rem;
            padding: 2rem;
        }
        .card {
            background: white;
            padding: 1rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: center;
            cursor: pointer;
        }
        .card:hover {
            background: #f0f2f5;
        }
        a {
            color: white;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h2>Hospital Management System</h2>
        <a href="logout.php">Logout</a>
    </div>
    <div class="menu">
        <div class="card">
            <h3>Patients</h3>
            <p>Manage patients</p>
        </div>
        <div class="card">
            <h3>Doctors</h3>
            <p>Manage doctors</p>
        </div>
        <div class="card">
            <h3>Appointments</h3>
            <p>Manage appointments</p>
        </div>
        <div class="card">
            <h3>Reports</h3>
            <p>View reports</p>
        </div>
    </div>
</body>
</html>