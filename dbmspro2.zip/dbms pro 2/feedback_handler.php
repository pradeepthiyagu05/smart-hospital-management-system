<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "contact";

try {
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Get form data
    $patient_name = mysqli_real_escape_string($conn, $_POST['patient_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $service_type = mysqli_real_escape_string($conn, $_POST['service_type']);
    $rating = (int)$_POST['rating'];
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    // Validate data
    if (empty($patient_name) || empty($email) || empty($service_type) || empty($comment)) {
        throw new Exception("All fields are required");
    }

    // Validate rating
    if ($rating < 1 || $rating > 5) {
        throw new Exception("Invalid rating value");
    }

    // Insert data into feedback table
    $sql = "INSERT INTO feedback (patient_name, email, service_type, rating, comment) 
            VALUES ('$patient_name', '$email', '$service_type', $rating, '$comment')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode([
            "status" => "success",
            "message" => "Thank you for your feedback!"
        ]);
    } else {
        throw new Exception("Error: " . $sql . "<br>" . $conn->error);
    }

    $conn->close();
} catch (Exception $e) {
    error_log("Feedback submission error: " . $e->getMessage());
    echo json_encode([
        "status" => "error",
        "message" => $e->getMessage()
    ]);
}
?>