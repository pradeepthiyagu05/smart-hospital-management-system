<?php
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "contact";

try {
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Get form data
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $preferred_date = mysqli_real_escape_string($conn, $_POST['date']);
    $preferred_time = mysqli_real_escape_string($conn, $_POST['time']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);
    $reason = mysqli_real_escape_string($conn, $_POST['reason']);

    // Insert data into appoinment table
    $sql = "INSERT INTO appoinment (name, phone, email, preferred_date, preferred_time, department, reason) 
            VALUES ('$name', '$phone', '$email', '$preferred_date', '$preferred_time', '$department', '$reason')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["status" => "success", "message" => "Appointment booked successfully!"]);
    } else {
        throw new Exception("Error: " . $sql . "<br>" . $conn->error);
    }

    $conn->close();
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>